# Iran/US cinematic plates — Blender 4.5 EEVEE. Renders plate/f_####.jpg (frame = int(T*24)+1).
import bpy, bmesh, math, os, sys, json, random
import numpy as np
from mathutils import Vector, Euler, Matrix, noise

A = os.environ.get('ASSET_DIR', os.getcwd())
OUT = os.environ.get('PLATE_DIR', os.path.join(A, 'plate'))
FS, FE = int(os.environ.get('FRAME_START', 1)), int(os.environ.get('FRAME_END', 1))
STILLS = json.loads(os.environ.get('STILLS', '[]'))
LOCAL = os.environ.get('LOCAL') == '1'
EXPORT = os.environ.get('EXPORT_LABELS') == '1'
FPS = 24
RX, RY = (int(os.environ.get('RX', 810)), int(os.environ.get('RY', 1440)))
def P(n): return os.path.join(A, n)
def T2F(t): return int(t * FPS) + 1
def F2T(f): return (f - 1) / FPS

bpy.ops.wm.read_factory_settings(use_empty=True)
D = bpy.data; C = bpy.context; sc = C.scene
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- helpers
def mat(name):
    m = D.materials.new(name); m.use_nodes = True
    return m, m.node_tree.nodes, m.node_tree.links

def link(ob):
    sc.collection.objects.link(ob); return ob

def empty(name):
    return link(D.objects.new(name, None))

def smooth(t): t = max(0., min(1., t)); return t * t * (3 - 2 * t)
def lerp(a, b, t): return a + (b - a) * t
def V(*a): return Vector(a)
def clamp01(x): return max(0., min(1., x))

# ---------------------------------------------------------------- world + sun
HDR = P('hdri/sky.hdr')
w = D.worlds.new('W'); sc.world = w; w.use_nodes = True
wn = w.node_tree.nodes; wl = w.node_tree.links; wn.clear()
wo = wn.new('ShaderNodeOutputWorld'); bg = wn.new('ShaderNodeBackground')
env = wn.new('ShaderNodeTexEnvironment'); tc = wn.new('ShaderNodeTexCoord'); mp = wn.new('ShaderNodeMapping')
env.image = D.images.load(HDR)
wl.new(tc.outputs['Generated'], mp.inputs[0]); wl.new(mp.outputs[0], env.inputs[0])
wl.new(env.outputs[0], bg.inputs[0]); wl.new(bg.outputs[0], wo.inputs['Surface'])
vol = wn.new('ShaderNodeVolumePrincipled'); vol.inputs['Density'].default_value = 0.0
vol.inputs['Color'].default_value = (1.0, 0.85, 0.75, 1); vol.inputs['Anisotropy'].default_value = 0.6
if not LOCAL: wl.new(vol.outputs[0], wo.inputs['Volume'])

# brightest pixel = sun direction in env space
im = env.image; iw, ih = im.size
px = np.empty(iw * ih * 4, np.float32); im.pixels.foreach_get(px); px = px.reshape(ih, iw, 4)
lum = px[..., 0] + px[..., 1] + px[..., 2]
iy, ix = np.unravel_index(np.argmax(lum), lum.shape)
SUN_PHI = ((ix + .5) / iw - 0.5) * 2 * math.pi; SUN_TH = max(((iy + .5) / ih - 0.5) * math.pi, math.radians(2))
del px, lum
def env_dir(phi, th): return V(-math.cos(phi) * math.cos(th), math.sin(phi) * math.cos(th), math.sin(th))
SUN_ENV = env_dir(SUN_PHI, SUN_TH)
sunL = D.lights.new('sun', 'SUN'); sunL.color = (1.0, 0.72, 0.45); sunL.angle = math.radians(1.5)
sun = link(D.objects.new('sun', sunL))

def set_sun_azimuth(az_deg, strength_env=1.0, sun_energy=4.0):
    """rotate env so the HDRI sun sits at world azimuth az (deg, 0=+X, 90=+Y)."""
    env_az = math.atan2(SUN_ENV.y, SUN_ENV.x)
    rz = env_az - math.radians(az_deg)          # world dir = Rz(-rz) * env dir
    mp.inputs['Rotation'].default_value[2] = rz
    d = Matrix.Rotation(-rz, 3, 'Z') @ SUN_ENV
    sun.rotation_euler = (-d).to_track_quat('-Z', 'Y').to_euler()
    bg.inputs[1].default_value = strength_env; sunL.energy = sun_energy

# ---------------------------------------------------------------- render settings
sc.render.engine = 'BLENDER_EEVEE_NEXT'
sc.render.resolution_x, sc.render.resolution_y = RX, RY
sc.render.fps = FPS
e = sc.eevee
e.taa_render_samples = 24 if not LOCAL else 4
e.use_raytracing = True; e.ray_tracing_options.resolution_scale = '2'
e.use_shadows = True; e.shadow_ray_count = 1; e.shadow_step_count = 6
e.volumetric_tile_size = '8'; e.volumetric_samples = 48; e.use_volumetric_shadows = True
e.volumetric_end = 6000; e.use_gtao = True; e.fast_gi_method = 'GLOBAL_ILLUMINATION'
e.clamp_surface_indirect = 10
sc.view_settings.view_transform = 'AgX'; sc.view_settings.look = 'AgX - Medium High Contrast'
sc.render.image_settings.file_format = 'JPEG'; sc.render.image_settings.quality = 93
if LOCAL:
    sc.render.engine = 'CYCLES'; sc.cycles.samples = int(os.environ.get('SAMPLES', 10)); sc.cycles.use_denoising = True
    sc.cycles.volume_step_rate = 4

# compositor glow + slight chromatic dispersion
sc.use_nodes = True; ct = sc.node_tree; ct.nodes.clear()
rl = ct.nodes.new('CompositorNodeRLayers'); gl = ct.nodes.new('CompositorNodeGlare')
gl.glare_type = 'FOG_GLOW'; gl.quality = 'MEDIUM'
try: gl.threshold = 1.2; gl.size = 8; gl.mix = -0.75
except Exception: pass
ld = ct.nodes.new('CompositorNodeLensdist'); ld.inputs['Dispersion'].default_value = 0.012
co = ct.nodes.new('CompositorNodeComposite')
ct.links.new(rl.outputs['Image'], gl.inputs['Image']); ct.links.new(gl.outputs['Image'], ld.inputs['Image'])
ct.links.new(ld.outputs['Image'], co.inputs['Image'])

# ---------------------------------------------------------------- camera
camd = D.cameras.new('Cam'); camd.lens = 35; camd.clip_start = 0.3; camd.clip_end = 30000
camd.sensor_fit = 'VERTICAL'; camd.sensor_height = 24
cam = link(D.objects.new('Cam', camd)); sc.camera = cam
focus = empty('focus'); camd.dof.focus_object = focus

def look(ob, target, roll=0.):
    d = Vector(target) - ob.location
    q = d.to_track_quat('-Z', 'Y'); ob.rotation_euler = q.to_euler()
    if roll: ob.rotation_euler.rotate_axis('Z', roll)

# ---------------------------------------------------------------- ocean
def water_mat(name, foam=True):
    m, n, l = mat(name); bs = n['Principled BSDF']
    deep = (0.006, 0.02, 0.028, 1)
    bs.inputs['Base Color'].default_value = deep; bs.inputs['Roughness'].default_value = 0.035
    bs.inputs['IOR'].default_value = 1.333; bs.inputs['Specular IOR Level'].default_value = 0.55
    tcn = n.new('ShaderNodeTexCoord')
    nz = n.new('ShaderNodeTexNoise'); nz.inputs['Scale'].default_value = 0.08; nz.inputs['Detail'].default_value = 12
    nz.inputs['Roughness'].default_value = 0.6
    bump = n.new('ShaderNodeBump'); bump.inputs['Strength'].default_value = 0.12; bump.inputs['Distance'].default_value = 0.4
    l.new(tcn.outputs['Object'], nz.inputs['Vector']); l.new(nz.outputs['Fac'], bump.inputs['Height'])
    l.new(bump.outputs['Normal'], bs.inputs['Normal'])
    if foam:
        at = n.new('ShaderNodeAttribute'); at.attribute_name = 'foam'
        cr = n.new('ShaderNodeValToRGB'); cr.color_ramp.elements[0].position = 0.45; cr.color_ramp.elements[1].position = 1.0
        mx = n.new('ShaderNodeMix'); mx.data_type = 'RGBA'
        mx.inputs[6].default_value = deep; mx.inputs[7].default_value = (0.6, 0.62, 0.64, 1)
        l.new(at.outputs['Fac'], cr.inputs[0]); l.new(cr.outputs[0], mx.inputs[0]); l.new(mx.outputs[2], bs.inputs['Base Color'])
        rr = n.new('ShaderNodeMapRange'); rr.inputs[3].default_value = 0.035; rr.inputs[4].default_value = 0.5
        l.new(cr.outputs[0], rr.inputs[0]); l.new(rr.outputs[0], bs.inputs['Roughness'])
    return m

OCEAN_SIZE = 1400
bpy.ops.mesh.primitive_plane_add(size=2); ocean = C.active_object; ocean.name = 'Ocean'
om = ocean.modifiers.new('ocean', 'OCEAN'); om.geometry_mode = 'GENERATE'; om.spatial_size = 70
om.repeat_x = om.repeat_y = OCEAN_SIZE // 70; om.resolution = 9 if not LOCAL else 7
om.wave_scale = 1.6; om.choppiness = 1.1; om.wind_velocity = 14; om.use_foam = True
om.foam_layer_name = 'foam'; om.foam_coverage = 0.2; om.wave_alignment = 0.3
ocean.location = (-OCEAN_SIZE / 2, -OCEAN_SIZE / 2, 0)
ocean.data.materials.append(water_mat('Water'))
for p in ocean.data.polygons: p.use_smooth = True
bmf = bmesh.new(); R0 = OCEAN_SIZE / 2 - 25; R1 = 40000
def q(a, b, c, d): bmf.faces.new([bmf.verts.new(v) for v in (a, b, c, d)])
q((-R1, -R1, 0), (R1, -R1, 0), (R1, -R0, 0), (-R1, -R0, 0)); q((-R1, R0, 0), (R1, R0, 0), (R1, R1, 0), (-R1, R1, 0))
q((-R1, -R0, 0), (-R0, -R0, 0), (-R0, R0, 0), (-R1, R0, 0)); q((R0, -R0, 0), (R1, -R0, 0), (R1, R0, 0), (R0, R0, 0))
fme = D.meshes.new('FarSea'); bmf.to_mesh(fme); bmf.free(); far = link(D.objects.new('FarSea', fme)); far.location.z = -0.35
far.data.materials.append(water_mat('FarWater', foam=False))

# ---------------------------------------------------------------- models
def load(name, length, fwd='+x'):
    before = set(D.objects); bpy.ops.import_scene.gltf(filepath=P('models/' + name))
    new = [o for o in D.objects if o not in before]
    root = empty(name + '_root')
    for o in new:
        if o.parent is None: o.parent = root
    C.view_layer.update()
    pts = [o.matrix_world @ Vector(c) for o in new if o.type == 'MESH' for c in o.bound_box]
    mn = V(*[min(p[i] for p in pts) for i in range(3)]); mx = V(*[max(p[i] for p in pts) for i in range(3)])
    s = length / (mx.x - mn.x)
    piv = empty(name)
    root.parent = piv; root.scale = (s, s, s)
    root.location = (-(mn.x + mx.x) / 2 * s, -(mn.y + mx.y) / 2 * s, -mn.z * s)
    meshes = [o for o in new if o.type == 'MESH']
    return piv, meshes, (mx - mn) * s

def dup(piv, name):
    """linked duplicate of a loaded model hierarchy"""
    newp = empty(name)
    def rec(o, parent):
        c = o.copy(); link(c); c.parent = parent
        for ch in o.children: rec(ch, c)
    for ch in piv.children: rec(ch, newp)
    return newp

def grey_mat(name, col, rough=0.6, metal=0.25, scale=0.05):
    m, n, l = mat(name); bs = n['Principled BSDF']
    tcn = n.new('ShaderNodeTexCoord'); nz = n.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = scale; nz.inputs['Detail'].default_value = 10
    l.new(tcn.outputs['Object'], nz.inputs['Vector'])
    cr = n.new('ShaderNodeValToRGB'); cr.color_ramp.elements[0].color = (*[c * 0.55 for c in col], 1)
    cr.color_ramp.elements[1].color = (*col, 1); l.new(nz.outputs['Fac'], cr.inputs[0])
    l.new(cr.outputs[0], bs.inputs['Base Color'])
    rr = n.new('ShaderNodeMapRange'); rr.inputs[3].default_value = rough - 0.15; rr.inputs[4].default_value = rough + 0.2
    l.new(nz.outputs['Fac'], rr.inputs[0]); l.new(rr.outputs[0], bs.inputs['Roughness'])
    bs.inputs['Metallic'].default_value = metal
    return m

# carrier (USS Nimitz by Warfare, Sketchfab, CC-BY-4.0): procedural paint — deck dark, hull haze grey
carrier, cmesh, cdim = load('nimitz.glb', 333)
deck_img = D.images.load(P('deck.png'))
def carrier_mat():
    m, n, l = mat('Carrier'); bs = n['Principled BSDF']
    geo = n.new('ShaderNodeNewGeometry'); tcn = n.new('ShaderNodeTexCoord')
    sep = n.new('ShaderNodeSeparateXYZ'); l.new(geo.outputs['Normal'], sep.inputs[0])
    up = n.new('ShaderNodeMath'); up.operation = 'GREATER_THAN'; up.inputs[1].default_value = 0.93
    l.new(sep.outputs['Z'], up.inputs[0])
    # deck texture projected from above in carrier-local space
    img = n.new('ShaderNodeTexImage'); img.image = deck_img; img.extension = 'CLIP'
    mpn = n.new('ShaderNodeMapping'); mpn.vector_type = 'POINT'
    l.new(tcn.outputs['Object'], mpn.inputs[0]); l.new(mpn.outputs[0], img.inputs[0])
    m['map'] = mpn.name
    nz = n.new('ShaderNodeTexNoise'); nz.inputs['Scale'].default_value = 0.08; nz.inputs['Detail'].default_value = 10
    l.new(tcn.outputs['Object'], nz.inputs['Vector'])
    crh = n.new('ShaderNodeValToRGB'); crh.color_ramp.elements[0].color = (0.17, 0.18, 0.19, 1)
    crh.color_ramp.elements[1].color = (0.36, 0.37, 0.39, 1); l.new(nz.outputs['Fac'], crh.inputs[0])
    mx = n.new('ShaderNodeMix'); mx.data_type = 'RGBA'
    l.new(up.outputs[0], mx.inputs[0]); l.new(crh.outputs[0], mx.inputs[6]); l.new(img.outputs['Color'], mx.inputs[7])
    l.new(mx.outputs[2], bs.inputs['Base Color'])
    bs.inputs['Roughness'].default_value = 0.62; bs.inputs['Metallic'].default_value = 0.2
    return m
cm = carrier_mat()
for o in cmesh:
    o.data.materials.clear(); o.data.materials.append(cm)
# deck mapping: carrier-object local coords are the glTF node coords; fit image to deck bbox in carrier space
C.view_layer.update()
inv = carrier.matrix_world.inverted()
pts = [inv @ (o.matrix_world @ Vector(c)) for o in cmesh for c in o.bound_box]
cmn = V(*[min(p[i] for p in pts) for i in range(3)]); cmx = V(*[max(p[i] for p in pts) for i in range(3)])
# object coords differ per mesh object; simpler: use generated mapping per mesh via drivers -> use world-ish via carrier space below
for o in cmesh:
    o['_'] = 1
# replace Object coords by an object-space of the carrier pivot (TexCoord.object)
for nd in cm.node_tree.nodes:
    if nd.type == 'TEX_COORD': nd.object = carrier
mpn = cm.node_tree.nodes[cm['map']]
mpn.inputs['Location'].default_value = (-cmn.x / (cmx.x - cmn.x), -cmn.y / (cmx.y - cmn.y), 0)
mpn.inputs['Scale'].default_value = (1 / (cmx.x - cmn.x), 1 / (cmx.y - cmn.y), 1)
CARRIER_BOX = (cmn, cmx)

tanker, _, tdim = load('tanker.glb', 250)
tankers = [tanker] + [dup(tanker, f'tanker{i}') for i in range(1, 4)]
destroyer, _, ddim = load('destroyer.glb', 155)
jet, _, jdim = load('jet.glb', 17)
jets = [jet] + [dup(jet, f'jet{i}') for i in range(1, 3)]

# ---- drone (Shahed-like delta), mine
def make_drone(name):
    bm = bmesh.new()
    vs = [bm.verts.new(v) for v in [(1.6, 0, 0.05), (-1.4, 1.25, 0), (-1.2, 0, 0.12), (-1.4, -1.25, 0), (-1.2, 0, -0.06)]]
    bm.faces.new([vs[0], vs[1], vs[2]]); bm.faces.new([vs[0], vs[2], vs[3]])
    bm.faces.new([vs[0], vs[4], vs[1]]); bm.faces.new([vs[0], vs[3], vs[4]])
    bm.faces.new([vs[1], vs[4], vs[2]]); bm.faces.new([vs[2], vs[4], vs[3]])
    me = D.meshes.new(name); bm.to_mesh(me); bm.free()
    ob = link(D.objects.new(name, me))
    bpy.ops.mesh.primitive_cylinder_add(radius=0.16, depth=2.6, rotation=(0, math.pi / 2, 0), location=(0.1, 0, 0.06))
    fus = C.active_object; fus.parent = ob
    for sx in (1, -1):
        bpy.ops.mesh.primitive_cube_add(size=1, location=(-1.3, 1.18 * sx, 0.25), scale=(0.25, 0.03, 0.25)); C.active_object.parent = ob
    mt = grey_mat('drone', (0.42, 0.42, 0.40), 0.55, 0.1, 0.5)
    for o in [ob] + list(ob.children): o.data.materials.append(mt)
    return ob
drones = [make_drone(f'drone{i}') for i in range(6)]

def make_mine(name):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.9, segments=32, ring_count=16); ob = C.active_object; ob.name = name
    for i in range(10):
        a = i * 2.4; z = math.cos(i * 1.7) * 0.6
        d = V(math.cos(a), math.sin(a), z).normalized()
        bpy.ops.mesh.primitive_cone_add(radius1=0.12, radius2=0.07, depth=0.42, location=d * 0.98)
        h = C.active_object; h.rotation_euler = d.to_track_quat('Z', 'Y').to_euler(); h.parent = ob
        h.matrix_parent_inverse = ob.matrix_world.inverted()
    mt = grey_mat('mine', (0.06, 0.05, 0.045), 0.55, 0.6, 2.5)
    for o in [ob] + list(ob.children): o.data.materials.append(mt)
    bpy.ops.object.shade_smooth()
    return ob
mine = make_mine('mine')

# ---------------------------------------------------------------- volumes: fire, smoke, blast
def vol_mat(name, dens, col, emit=0.0, temp=1400, scroll=None, shape='ball'):
    m, n, l = mat(name); n.remove(n['Principled BSDF']); out = n['Material Output']
    pv = n.new('ShaderNodeVolumePrincipled'); l.new(pv.outputs[0], out.inputs['Volume'])
    tcn = n.new('ShaderNodeTexCoord'); mpn = n.new('ShaderNodeMapping'); mpn.name = 'scroll'
    l.new(tcn.outputs['Object'], mpn.inputs[0])
    nz = n.new('ShaderNodeTexNoise'); nz.noise_dimensions = '4D'; nz.name = 'nz'
    nz.inputs['Scale'].default_value = 2.2; nz.inputs['Detail'].default_value = 6; nz.inputs['Roughness'].default_value = 0.6
    l.new(mpn.outputs[0], nz.inputs['Vector'])
    # radial falloff (object space, unit cube/sphere)
    ln = n.new('ShaderNodeVectorMath'); ln.operation = 'LENGTH'
    if shape == 'column':
        sq = n.new('ShaderNodeVectorMath'); sq.operation = 'MULTIPLY'; sq.inputs[1].default_value = (1, 1, 0.35)
        l.new(tcn.outputs['Object'], sq.inputs[0]); l.new(sq.outputs[0], ln.inputs[0])
    else: l.new(tcn.outputs['Object'], ln.inputs[0])
    fall = n.new('ShaderNodeMapRange'); fall.inputs[1].default_value = 1.0; fall.inputs[2].default_value = 0.2
    l.new(ln.outputs['Value'], fall.inputs[0])
    mul = n.new('ShaderNodeMath'); mul.operation = 'MULTIPLY'; l.new(nz.outputs['Fac'], mul.inputs[0]); l.new(fall.outputs[0], mul.inputs[1])
    thr = n.new('ShaderNodeMapRange'); thr.inputs[1].default_value = 0.28; thr.inputs[2].default_value = 0.75
    l.new(mul.outputs[0], thr.inputs[0])
    dm = n.new('ShaderNodeMath'); dm.operation = 'MULTIPLY'; dm.inputs[1].default_value = dens; dm.name = 'dens'
    l.new(thr.outputs[0], dm.inputs[0]); l.new(dm.outputs[0], pv.inputs['Density'])
    pv.inputs['Color'].default_value = (*col, 1)
    if emit:
        em = n.new('ShaderNodeMath'); em.operation = 'MULTIPLY'; em.inputs[1].default_value = emit; em.name = 'emit'
        pw = n.new('ShaderNodeMath'); pw.operation = 'POWER'; pw.inputs[1].default_value = 2.0
        l.new(thr.outputs[0], pw.inputs[0]); l.new(pw.outputs[0], em.inputs[0])
        l.new(em.outputs[0], pv.inputs['Blackbody Intensity'])
        pv.inputs['Temperature'].default_value = temp
    return m

def vol_obj(name, m, shape='sphere'):
    if shape == 'sphere': bpy.ops.mesh.primitive_ico_sphere_add(radius=1, subdivisions=2)
    else: bpy.ops.mesh.primitive_cube_add(size=2)
    ob = C.active_object; ob.name = name; ob.data.materials.append(m); return ob

def set_vol(ob, t, dens=None, emit=None):
    nt = ob.active_material.node_tree
    nt.nodes['nz'].inputs['W'].default_value = t * 0.6
    nt.nodes['scroll'].inputs['Location'].default_value[2] = -t * 0.35
    if dens is not None: nt.nodes['dens'].inputs[1].default_value = dens
    if emit is not None and 'emit' in nt.nodes: nt.nodes['emit'].inputs[1].default_value = emit

def plight(name, col, energy=0, r=1):
    L = D.lights.new(name, 'POINT'); L.color = col; L.energy = energy; L.shadow_soft_size = r
    return link(D.objects.new(name, L))

# big fire set (hook tanker): fireball, fire, smoke column, spray
fire_m = vol_mat('fire', 6, (0.2, 0.1, 0.05), emit=40, temp=1300)
fire = vol_obj('fire', fire_m)
smoke_m = vol_mat('smoke', 1.6, (0.04, 0.035, 0.03), shape='column')
smoke = vol_obj('smoke', smoke_m, 'box')
ball_m = vol_mat('ball', 8, (0.3, 0.15, 0.05), emit=120, temp=1700)
ball = vol_obj('ball', ball_m)
spray_m = vol_mat('spray', 3, (0.8, 0.82, 0.85))
spray = vol_obj('spray', spray_m)
fireL = plight('fireL', (1, 0.45, 0.15), 0, 8)
# map fires (many small emissive + smoke puffs)
mfire_m = vol_mat('mfire', 8, (0.2, 0.1, 0.05), emit=60, temp=1350)
msmoke_m = vol_mat('msmoke', 3, (0.05, 0.045, 0.04), shape='column')
mfires = []
for i in range(25):
    f1 = vol_obj(f'mf{i}', mfire_m); s1 = vol_obj(f'ms{i}', msmoke_m, 'box'); mfires.append((f1, s1))

def emis_mat(name, col, strength):
    m, n, l = mat(name); bs = n['Principled BSDF']
    bs.inputs['Base Color'].default_value = (0, 0, 0, 1)
    bs.inputs['Emission Color'].default_value = (*col, 1); bs.inputs['Emission Strength'].default_value = strength
    return m

# ---------------------------------------------------------------- map (terrain heightfield)
TJ = json.load(open(P('terrain.json'))); G = json.load(open(P('gulf.json'))); GP = G['pts']
MO = V(9000, 0, 0); MZ = 0.55   # map origin, vertical exaggeration
HN = np.load(P('height.npy'))   # rows = y south
HH, HW = HN.shape
def map_h(x, y):
    u = (x - TJ['X0']) / (TJ['X1'] - TJ['X0']) * (HW - 1); v = (y - TJ['Y0']) / (TJ['Y1'] - TJ['Y0']) * (HH - 1)
    u = min(max(u, 0), HW - 1); v = min(max(v, 0), HH - 1)
    return float(HN[int(v), int(u)])
def MP(x, y, h=0.0):  # map coords (x east, y south) -> world
    return MO + V(x, -y, h)
def MPg(x, y, h=0.0): return MP(x, y, max(map_h(x, y), 0) * MZ + h)

NX, NY = 680, 500
bpy.ops.mesh.primitive_grid_add(x_subdivisions=NX, y_subdivisions=NY, size=1)
terr = C.active_object; terr.name = 'Terrain'
mw, mh = TJ['X1'] - TJ['X0'], TJ['Y1'] - TJ['Y0']
me = terr.data; co = np.empty(len(me.vertices) * 3, np.float32); me.vertices.foreach_get('co', co); co = co.reshape(-1, 3)
xs = TJ['X0'] + (co[:, 0] + 0.5) * mw; ys = TJ['Y0'] + (0.5 - co[:, 1]) * mh
ui = np.clip(((xs - TJ['X0']) / mw * (HW - 1)).astype(int), 0, HW - 1); vi = np.clip(((ys - TJ['Y0']) / mh * (HH - 1)).astype(int), 0, HH - 1)
hz = HN[vi, ui]; hz = np.where(hz < 0, -0.05, hz) * MZ
co[:, 0] = xs; co[:, 1] = -ys; co[:, 2] = hz
me.vertices.foreach_set('co', co.ravel()); me.update()
terr.location = MO
uvl = me.uv_layers.active.data
loops = np.empty(len(me.loops), np.int32); me.loops.foreach_get('vertex_index', loops)
uv = np.stack([(xs[loops] - TJ['X0']) / mw, 1 - (ys[loops] - TJ['Y0']) / mh], 1).astype(np.float32)
uvl.foreach_set('uv', uv.ravel())
for p in me.polygons: p.use_smooth = True
tm_, tn, tl = mat('Terrain'); tbs = tn['Principled BSDF']
alb = tn.new('ShaderNodeTexImage'); alb.image = D.images.load(P('albedo.png')); tl.new(alb.outputs[0], tbs.inputs['Base Color'])
# water where z<0: glossy
gz = tn.new('ShaderNodeNewGeometry'); sz = tn.new('ShaderNodeSeparateXYZ'); tl.new(gz.outputs['Position'], sz.inputs[0])
wm = tn.new('ShaderNodeMapRange'); wm.inputs[1].default_value = -0.02; wm.inputs[2].default_value = 0.03
wm.inputs[3].default_value = 0.06; wm.inputs[4].default_value = 0.85; tl.new(sz.outputs['Z'], wm.inputs[0]); tl.new(wm.outputs[0], tbs.inputs['Roughness'])
tbs.inputs['Specular IOR Level'].default_value = 0.5
tnz = tn.new('ShaderNodeTexNoise'); tnz.inputs['Scale'].default_value = 3; tnz.inputs['Detail'].default_value = 8
tbp = tn.new('ShaderNodeBump'); tbp.inputs['Strength'].default_value = 0.05
tl.new(tnz.outputs['Fac'], tbp.inputs['Height']); tl.new(tbp.outputs['Normal'], tbs.inputs['Normal'])
me.materials.append(tm_)

# map props
mini_tankers = [dup(tanker, f'mt{i}') for i in range(25)]
for o in mini_tankers: o.scale = (0.0065,) * 3   # 250m -> 2.75 units
mini_car = dup(carrier, 'mini_car'); mini_car.scale = (0.012,) * 3
wall_m, wn_, wl_ = mat('wall'); wbs = wn_['Principled BSDF']
wbs.inputs['Base Color'].default_value = (0, 0, 0, 1); wbs.inputs['Emission Color'].default_value = (1, 0.05, 0.05, 1)
wbs.inputs['Emission Strength'].default_value = 6; wbs.inputs['Alpha'].default_value = 0.0
wtc = wn_.new('ShaderNodeTexCoord'); wsep = wn_.new('ShaderNodeSeparateXYZ'); wl_.new(wtc.outputs['Generated'], wsep.inputs[0])
wr = wn_.new('ShaderNodeMapRange'); wr.inputs[3].default_value = 0.85; wr.inputs[4].default_value = 0.0
wl_.new(wsep.outputs['Z'], wr.inputs[0]); wl_.new(wr.outputs[0], wbs.inputs['Alpha'])
wall_m.surface_render_method = 'BLENDED'
bpy.ops.mesh.primitive_plane_add(size=1); wall = C.active_object; wall.name = 'wall'
wall.data.materials.append(wall_m)
a, b = MP(*GP['strA']), MP(*GP['strB'])
wall.location = (a + b) / 2; wall.rotation_euler = (math.pi / 2, 0, math.atan2((b - a).y, (b - a).x))
WALL_LEN = (b - a).length
wallL = plight('wallL', (1, 0.1, 0.08), 0, 6)
# drones on map: emissive dots + trails; intercept bursts
dot_m = emis_mat('dot', (1, 0.55, 0.25), 30)
burst_m = emis_mat('burst', (1, 0.6, 0.3), 60)
pin_m = emis_mat('pin', (1, 0.08, 0.08), 12)
mdrones, mbursts = [], []
for i in range(6):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.35); d_ = C.active_object; d_.data.materials.append(dot_m); mdrones.append(d_)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=1); b_ = C.active_object; b_.data.materials.append(burst_m); mbursts.append(b_)
bpy.ops.mesh.primitive_torus_add(major_radius=1, minor_radius=0.06); pin = C.active_object; pin.data.materials.append(pin_m)
pinL = plight('pinL', (1, 0.1, 0.1), 0, 2)

# missiles (shot F): emissive heads + trails
mis_m = emis_mat('mis', (1, 0.6, 0.3), 80)
trail_m = vol_mat('trail', 2.5, (0.5, 0.48, 0.46), shape='column')
missiles = []
for i in range(3):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=6); h = C.active_object; h.data.materials.append(mis_m)
    tr = vol_obj(f'trail{i}', trail_m, 'box'); L = plight(f'misL{i}', (1, 0.55, 0.25), 0, 10)
    missiles.append((h, tr, L))

# afterburner + carrier stage lights
ab_m = emis_mat('ab', (1, 0.45, 0.15), 40)
burners = []
for j in jets:
    bpy.ops.mesh.primitive_cone_add(radius1=0.55, radius2=0.1, depth=3.2, rotation=(0, -math.pi / 2, 0))
    c_ = C.active_object; c_.data.materials.append(ab_m); burners.append(c_)
spots = []
for i in range(6):
    L = D.lights.new(f'spot{i}', 'SPOT'); L.energy = 0; L.spot_size = math.radians(9); L.spot_blend = 0.4
    L.color = (1, 0.93, 0.85); L.shadow_soft_size = 0.3
    spots.append(link(D.objects.new(f'spot{i}', L)))

# deck height via raycast
C.view_layer.update()
dg = C.evaluated_depsgraph_get()
hit = sc.ray_cast(dg, V(-60, 0, 500), V(0, 0, -1))
DECK = hit[1].z if hit[0] else 20.0
print('DECK', DECK, 'carrier dims', cdim)

HIDE = V(0, 0, -5000)
ALL_MOVERS = [carrier, destroyer, mine, fire, smoke, ball, spray, fireL, wall, wallL, pin, pinL, mini_car] + tankers + jets + drones \
    + mini_tankers + mdrones + mbursts + [x for f in mfires for x in f] + [x for m_ in missiles for x in m_] + burners + spots

def place(ob, loc, rz=0.0, scale=None, rx=0.0, ry=0.0):
    ob.location = loc; ob.rotation_euler = (rx, ry, rz)
    if scale is not None: ob.scale = scale if isinstance(scale, (tuple, list, Vector)) else (scale,) * 3

def bob(ob, loc, rz, t, amp=0.6, roll=0.012, ph=0.0):
    place(ob, Vector(loc) + V(0, 0, amp * math.sin(t * 0.7 + ph) - amp * 0.4), rz,
          rx=roll * math.sin(t * 0.55 + ph), ry=roll * 0.6 * math.sin(t * 0.43 + ph + 1))

# ---------------------------------------------------------------- camera path util
def campath(t, keys):
    """keys: [(t, loc, target, lens)] cosine-eased between consecutive keys"""
    if t <= keys[0][0]: k0 = k1 = keys[0]; u = 0
    elif t >= keys[-1][0]: k0 = k1 = keys[-1]; u = 0
    else:
        for i in range(len(keys) - 1):
            if keys[i][0] <= t <= keys[i + 1][0]: k0, k1 = keys[i], keys[i + 1]; break
        u = (t - k0[0]) / (k1[0] - k0[0])
    k = 0.5 - 0.5 * math.cos(math.pi * u)
    loc = Vector(k0[1]).lerp(Vector(k1[1]), k); tg = Vector(k0[2]).lerp(Vector(k1[2]), k)
    return loc, tg, lerp(k0[3], k1[3], k)

def shake(t, amp):
    return V(noise.noise(V(t * 1.3, 0, 0)), noise.noise(V(0, t * 1.1, 3)), noise.noise(V(5, 2, t * 1.2))) * amp

def setcam(t, keys, sh=0.15, dof=None, fstop=2.8, roll=0.0):
    loc, tg, lens = campath(t, keys)
    cam.location = loc + shake(t, sh); look(cam, tg + shake(t + 7, sh * 0.6), roll)
    camd.lens = lens
    camd.dof.use_dof = dof is not None
    if dof is not None: focus.location = dof; camd.dof.aperture_fstop = fstop

# ---------------------------------------------------------------- shots (T = final seconds, voice starts at 3.2)
SHOTS = []
def shot(t0, t1):
    def deco(fn): SHOTS.append((t0, t1, fn)); return fn
    return deco

def fire_at(t, loc, t_on, size=1.0, smoke_h=60):
    """sustained fire + smoke column on a burning ship"""
    if t < t_on: return
    k = smooth((t - t_on) / 1.5)
    place(fire, loc + V(0, 0, 6 * size), scale=(14 * size, 14 * size, 9 * size * (0.6 + 0.4 * k)))
    set_vol(fire, t, dens=6, emit=40 * k)
    place(smoke, loc + V(-8 * size, 0, 6 * size + smoke_h * k), scale=(22 * size, 22 * size, smoke_h * k + 1), rz=0.3)
    set_vol(smoke, t * 0.6, dens=1.4 * k)
    place(fireL, loc + V(0, 0, 14 * size)); fireL.data.energy = (2.5e5 + 6e4 * math.sin(t * 13) * math.sin(t * 7.3)) * k * size

@shot(0.0, 10.7)
def s_hook(t):
    set_sun_azimuth(70, 0.9, 3.5); vol.inputs['Density'].default_value = 0.00025
    bob(tankers[0], (0, 0, -9), math.radians(-5), t, 0.5)
    mine_loc = V(-20, -17, 0.2 + 0.25 * math.sin(t * 1.4))
    if t < 1.45: place(mine, mine_loc, t * 0.1)
    # blast at 1.4
    if 1.4 <= t < 3.4:
        k = (t - 1.4) / 2.0
        place(ball, V(-18, -15, 6 + 18 * k), scale=8 + 30 * smooth(k * 2.5))
        set_vol(ball, t, dens=6, emit=140 * (1 - smooth(k)) ** 2)
        place(spray, V(-20, -17, 10 + 25 * smooth(k * 1.5)), scale=(10 + 14 * k, 10 + 14 * k, 6 + 30 * smooth(k * 2)))
        set_vol(spray, t, dens=2.5 * (1 - smooth(k)))
        fireL.data.energy = 3e6 * (1 - smooth(k * 3)); place(fireL, V(-22, -25, 12))
    else:
        fireL.data.energy = 0
    fire_at(t, V(-14, -8, 14), 1.9, 1.0, 70)
    keys = [(0.0, (-150, -150, 2.2), (-5, -5, 10), 30), (1.4, (-135, -138, 2.6), (-5, -5, 12), 30),
            (3.4, (-170, -190, 7), (0, 0, 22), 30), (10.7, (-260, -330, 50), (10, 0, 25), 32)]
    sh = 0.12 + (1.2 * max(0, 1 - (t - 1.4) / 1.2) if t > 1.4 else 0)
    setcam(t, keys, sh, dof=V(-20, -17, 2) if t < 1.5 else V(0, 0, 15), fstop=5.6 if t < 1.5 else 11)

MAP_TANKS = []
random.seed(4)
hz_ = GP['hormuz']
while len(MAP_TANKS) < 25:
    x = hz_[0] + random.uniform(-38, 30); y = hz_[1] + random.uniform(-26, 34)
    if map_h(x, y) < -0.06 and all((x - a_) ** 2 + (y - b_) ** 2 > 30 for a_, b_, _ in MAP_TANKS):
        MAP_TANKS.append((x, y, random.uniform(0, 6.28)))
MAP_TANKS.sort(key=lambda p: (p[0] - hz_[0]) ** 2 + (p[1] - hz_[1]) ** 2)

def map_tankers(t, ign0=13.6, gap=0.17, sail=True):
    for i, (o, (x, y, r)) in enumerate(zip(mini_tankers, MAP_TANKS)):
        dx = 0.25 * math.sin(t * 0.2 + i) if sail else 0
        place(o, MP(x + dx, y, -0.15), r)
        f1, s1 = mfires[i]; ti = ign0 + i * gap
        if t >= ti:
            k = smooth((t - ti) / 0.8)
            place(f1, MP(x, y, 0.5), scale=(0.9, 0.9, 0.8 * k + 0.05)); set_vol(f1, t + i, emit=60 * k)
            place(s1, MP(x - 0.6, y, 1.2 + 3.0 * k), scale=(1.2, 1.2, 3.2 * k + 0.1), rz=0.4); set_vol(s1, (t + i) * 0.6, dens=2.5 * k)

@shot(10.7, 31.3)
def s_hormuz(t):
    set_sun_azimuth(200, 1.0, 4.5); vol.inputs['Density'].default_value = 0.0
    map_tankers(t)
    if t >= 21.4:
        k = smooth((t - 21.4) / 1.2)
        wall.scale = (WALL_LEN, 4.5 * k + 0.01, 1); wall.location = (MP(*GP['strA']) + MP(*GP['strB'])) / 2 + V(0, 0, 2.25 * k)
        place(wallL, MP(85, 14, 3)); wallL.data.energy = 4000 * k
    if t >= 26.0:
        k = smooth((t - 26.0) / 5.3)
        p0, p1 = V(*GP['gom']), V(*GP['gulfOmanW'])
        pp = p0.lerp(p1, k); ang = math.atan2(-(p1 - p0).y, (p1 - p0).x)
        place(mini_car, MP(pp.x, pp.y, -0.2), ang)
    keys = [(10.7, MP(-10, 175, 170), MP(10, 10, 0), 30), (13.6, MP(55, 80, 70), MP(84, 12, 0), 30),
            (17.0, MP(62, 66, 42), MP(86, 12, 0), 32), (21.4, MP(100, 50, 26), MP(85, 14, 2), 32),
            (25.8, MP(112, 72, 24), MP(100, 40, 0), 32), (31.3, MP(98, 80, 14), MP(108, 48, 0), 34)]
    setcam(t, keys, 0.05)

@shot(31.3, 40.7)
def s_carrier(t):
    set_sun_azimuth(60, 0.95, 4.0); vol.inputs['Density'].default_value = 0.0003
    bob(carrier, (0, 0, -2), 0, t, 0.25, 0.004)
    bob(destroyer, (120, -170, -3), 0, t, 0.5, 0.015, 1)
    bob(tankers[1], (-420, -150, -9), 0, t, 0.4, 0.01, 2); bob(tankers[2], (-700, -120, -9), 0, t, 0.4, 0.01, 3)
    keys = [(31.3, (-480, -420, 95), (0, 0, 25), 38), (34.8, (-380, -460, 55), (-80, -60, 20), 38),
            (37.6, (-560, -330, 22), (-420, -150, 15), 40), (40.7, (-600, -300, 18), (-500, -140, 14), 42)]
    setcam(t, keys, 0.2)

@shot(40.7, 50.8)
def s_tools(t):
    set_sun_azimuth(105, 0.9, 3.5); vol.inputs['Density'].default_value = 0.00035
    bob(carrier, (0, 0, -2), 0, t, 0.25, 0.004)
    mloc = V(12, -330, 0.15 + 0.3 * math.sin(t * 1.3))
    place(mine, mloc, t * 0.07, rx=0.15 * math.sin(t))
    # drone passes over camera toward carrier 44.2..47
    if t >= 44.0:
        k = (t - 44.0) / 6.8
        p = V(-40, -360, 9).lerp(V(40, -60, 70), k)
        d = V(40, -60, 70) - V(-40, -360, 9)
        place(drones[0], p, math.atan2(d.y, d.x), ry=-0.08, rx=0.1 * math.sin(t * 3))
    if t < 45.9:
        keys = [(40.7, (0, -342, 1.0), mloc + V(0, 0, 0.4), 50), (45.9, (2, -339, 1.3), mloc + V(0, 0, 0.5), 50)]
        setcam(t, keys, 0.08, dof=mloc, fstop=2.0)
    else:
        dp = drones[0].location
        keys = [(45.9, (25, -250, 5), (0, 0, 40), 26), (50.8, (35, -230, 4), (0, 0, 45), 26)]
        setcam(t, keys, 0.1)
        look(cam, dp.lerp(V(0, 0, 40), smooth((t - 45.9) / 4)))

@shot(50.8, 61.8)
def s_destroyer(t):
    set_sun_azimuth(15, 0.85, 3.5); vol.inputs['Density'].default_value = 0.0005
    bob(destroyer, (0, 0, -3), math.radians(10), t, 0.6, 0.02)
    bob(carrier, (900, 700, -2), math.radians(10), t, 0.25, 0.004)
    keys = [(50.8, (-170, -110, 9), (0, 0, 12), 45), (61.8, (-105, -95, 7), (10, 5, 12), 45)]
    setcam(t, keys, 0.15)

@shot(61.8, 67.4)
def s_escalate(t):
    set_sun_azimuth(125, 0.7, 2.5); vol.inputs['Density'].default_value = 0.0004
    bob(destroyer, (180, 260, -3), math.radians(-30), t, 0.6, 0.02)
    for i, (h, tr, L) in enumerate(missiles):
        t0 = 66.3 + i * 0.25
        base = V(-1800 + i * 500, 3600, 0)
        if t >= t0:
            k = (t - t0); hgt = 30 + 260 * k * k + 120 * k
            p = base + V(40 * k * k, -150 * k, hgt)
            place(h, p); place(tr, (base + p) / 2 + V(0, 0, 10), scale=(14, 14, (p - base).length / 2 + 5))
            set_vol(tr, t + i, dens=2.0); L.location = p; L.data.energy = 4e7
    keys = [(61.8, (0, -80, 3), (0, 1000, 40), 40), (67.4, (0, -60, 3.5), (-200, 1000, 120), 40)]
    setcam(t, keys, 0.1)

@shot(67.4, 75.3)
def s_convoy(t):
    set_sun_azimuth(70, 0.95, 4.0); vol.inputs['Density'].default_value = 0.0003
    for i in range(3):
        bob(tankers[i], (-200 + i * 320, 60 * i, -9), math.radians(8), t, 0.4, 0.01, i)
    bob(destroyer, (150, -160, -3), math.radians(8), t, 0.5, 0.015)
    keys = [(67.4, (-420, -420, 210), (100, 60, 0), 34), (75.3, (-260, -470, 160), (180, 80, 0), 34)]
    setcam(t, keys, 0.1)

@shot(75.3, 82.9)
def s_launch(t):
    set_sun_azimuth(20, 1.0, 4.0); vol.inputs['Density'].default_value = 0.0002
    place(carrier, V(0, 0, -2), 0)
    # jet roll from stern to bow then climb
    x0 = -110
    if t < 77.0: x, z, pitch = x0, 0, 0
    else:
        k = t - 77.0; x = x0 + 14 * k * k + 6 * k
        z = max(0, (x - 165) * 0.18) + max(0, x - 200) ** 1.3 * 0.05; pitch = -min(0.25, max(0, (x - 165) * 0.004))
    place(jets[0], V(x, 12, DECK + z), 0, ry=pitch)
    b = burners[0]; b.location = jets[0].location + V(-9.5, 0, 1.6); b.rotation_euler = (0, -math.pi / 2 + pitch, 0)
    b.scale = (1, 1, 1.6 if t >= 76.6 else 0.01)
    keys = [(75.3, (-150, 40, DECK + 3), (-100, 12, DECK + 2), 30), (77.0, (-140, 38, DECK + 3), (-100, 12, DECK + 2), 30),
            (80.0, (-60, 45, DECK + 4), (120, 12, DECK + 6), 30), (82.9, (40, 50, DECK + 6), (330, 10, DECK + 60), 30)]
    setcam(t, keys, 0.2)

@shot(82.9, 86.6)
def s_jets(t):
    set_sun_azimuth(25, 1.0, 4.5); vol.inputs['Density'].default_value = 0.00025
    vx = 140; base = V(-500 + vx * (t - 82.9), 0, 120)
    offs = [V(0, 0, 0), V(-25, 22, -4), V(-25, -22, -4)]
    for j, o, b in zip(jets, offs, burners):
        p = base + o + V(0, 0, 1.2 * math.sin(t * 2 + o.y))
        place(j, p, 0, rx=0.03 * math.sin(t * 1.5 + o.y))
        b.location = p + V(-9.5, 0, 1.6); b.rotation_euler = (0, -math.pi / 2, 0); b.scale = (1, 1, 1.4)
    cam.location = base + V(-55, -30, 6) + shake(t, 0.4); look(cam, base + V(10, 0, 0)); camd.lens = 32; camd.dof.use_dof = False

@shot(86.6, 99.2)
def s_kuwait(t):
    set_sun_azimuth(230, 1.0, 4.5); vol.inputs['Density'].default_value = 0.0
    map_tankers(t, ign0=-100, sail=True)
    bu, ku = V(*GP['bushehr']), V(*GP['kuwait'])
    for i, (d_, b_) in enumerate(zip(mdrones, mbursts)):
        t0 = 87.8 + i * 0.35; dur = 3.0 + 0.2 * i; tk = t0 + dur * (0.72 + 0.05 * (i % 3))
        if t0 <= t < tk:
            k = (t - t0) / dur
            p = bu.lerp(ku + V(4 * (i % 3 - 1), 3 * (i % 2), 0), k) + V(0, 3 * math.sin(i) * math.sin(k * math.pi), 0)
            place(d_, MP(p.x, p.y, 2.5 + 9 * math.sin(k * math.pi)))
        elif t >= tk:
            bp = MP(*(bu.lerp(ku, (tk - t0) / dur)), 2.5 + 9 * math.sin((tk - t0) / dur * math.pi))
            kk = (t - tk) / 0.9
            if kk < 1:
                place(b_, bp, scale=0.3 + 2.2 * smooth(kk)); b_.active_material = burst_m
                b_.scale *= 1
                b_.hide_render = False
            else: place(b_, HIDE)
            place(d_, HIDE)
    if t >= 87.0:
        k = (t * 0.8) % 1
        place(pin, MPg(*GP['kuwait'], 0.3), scale=(1 + 3 * k, 1 + 3 * k, 1))
        place(pinL, MPg(*GP['kuwait'], 2)); pinL.data.energy = 1500
    keys = [(86.6, MP(-40, 40, 90), MP(-85, -50, 0), 30), (93.0, MP(-80, 10, 55), MP(-105, -55, 0), 32),
            (99.2, MP(-100, -15, 34), MP(-115, -58, 0), 34)]
    setcam(t, keys, 0.05)

@shot(99.2, 110.1)
def s_show(t):
    set_sun_azimuth(200, 0.75, 3.0); vol.inputs['Density'].default_value = 0.0008
    bob(carrier, (0, 0, -2), 0, t, 0.25, 0.004)
    k = smooth((t - 106.9) / 0.6)
    for i, s_ in enumerate(spots):
        side = -1 if i % 2 else 1; xx = -120 + (i // 2) * 120
        s_.location = V(xx, side * 160, 6)
        tgt = V(xx * 0.6 + 30 * math.sin(t * 0.7 + i), side * 10, 40 + 25 * math.sin(t * 0.5 + i))
        d = tgt - s_.location; s_.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()
        s_.data.energy = 6e6 * k
    ang = math.radians(-120 + (t - 99.2) * 4.0)
    loc = V(math.cos(ang) * 520, math.sin(ang) * 520, 45 - (t - 99.2) * 1.5)
    cam.location = loc + shake(t, 0.15); look(cam, V(0, 0, 30)); camd.lens = 40; camd.dof.use_dof = False

@shot(110.1, 124.0)
def s_end(t):
    set_sun_azimuth(10, 1.0, 4.0); vol.inputs['Density'].default_value = 0.0003
    bob(carrier, (300, 0, -2), math.radians(180), t, 0.25, 0.004)
    bob(destroyer, (120, 180, -3), math.radians(180), t, 0.5, 0.015)
    for i in range(2): bob(tankers[i], (-300 - i * 380, -260 - i * 60, -9), math.radians(175), t, 0.4, 0.01, i)
    keys = [(110.1, (-40, -40, 2.5), (300, 0, 20), 30), (117.0, (-140, -120, 90), (200, 0, 10), 30),
            (124.0, (-260, -200, 230), (300, 0, 0), 28)]
    setcam(t, keys, 0.12)

def shot_at(t):
    for t0, t1, fn in SHOTS:
        if t0 <= t < t1: return fn
    return SHOTS[-1][2]

def update(f):
    t = F2T(f)
    for o in ALL_MOVERS:
        if o.type == 'LIGHT' and o is not sun: o.data.energy = 0
        o.location = HIDE; o.rotation_euler = (0, 0, 0)
    for o in mini_tankers: o.scale = (0.0065,) * 3
    mini_car.scale = (0.012,) * 3
    for b in burners: b.scale = (1, 1, 1)
    shot_at(t)(t)
    sc.frame_set(f)
    om.time = t * 1.0

# ---------------------------------------------------------------- label export (map shots), run locally
LABELS = {'هرمز': GP['hormuz'], 'إيران': (40, -60), 'الخليج العربي': (-20, 10), 'خليج عُمان': (140, 70),
          'الكويت': GP['kuwait'], 'بوشهر': GP['bushehr'], 'الإمارات': (30, 75), 'عُمان': (95, 85), 'السعودية': (-90, 40)}
if EXPORT:
    from bpy_extras.object_utils import world_to_camera_view
    out = {'fps': FPS, 'shots': {}}
    for name, (t0, t1) in {'hormuz': (10.7, 31.3), 'kuwait': (86.6, 99.2)}.items():
        fr = {}
        for f in range(T2F(t0), T2F(t1)):
            update(f); C.view_layer.update()
            row = {}
            for k_, (x, y) in LABELS.items():
                pw = MPg(x, y, 0.3)
                c = world_to_camera_view(sc, cam, pw)
                if c.z > 0: row[k_] = [round(c.x, 4), round(1 - c.y, 4)]
            fr[f] = row
        out['shots'][name] = fr
    json.dump(out, open(os.path.join(A, 'labels.json'), 'w'), ensure_ascii=False)
    print('labels exported'); sys.exit(0)

# ---------------------------------------------------------------- render
frames = STILLS if STILLS else list(range(FS, FE + 1))
for f in frames:
    update(f)
    sc.render.filepath = os.path.join(OUT, 'f_%04d.jpg' % f)
    bpy.ops.render.render(write_still=True)
print('done', len(frames))

// محرك old-good بهوية «شبكة» (نسخة المشروع، مهارة old-good نفسها ما تنلمس)
const OR='#E3262E',AM='#F5A524',IV='#EFEAE0',GR='#8B8789',SURF='#1B191A',BG='#0E0C0D',RD='#E3262E',INK='#0E0C0D',WH='#FFFFFF';
const NS='http://www.w3.org/2000/svg', FX={shake:0,red:0,flip:0};
let tl, world, cx; let _uid=0;const uid=p=>p+(++_uid);
const px=v=>typeof v==='number'?v+'px':v;
function el(tag,cls,css,par){const e=document.createElement(tag);if(cls)e.className=cls;Object.assign(e.style,css||{});(par||world).appendChild(e);return e}
const box=(cls,x,y,w,h,par,css)=>el('div',cls,{left:px(x),top:px(y),width:px(w),height:px(h),...(css||{})},par);
function sv(w,h,par,css){const s=document.createElementNS(NS,'svg');s.setAttribute('width',w);s.setAttribute('height',h);s.setAttribute('viewBox',`0 0 ${w} ${h}`);Object.assign(s.style,{position:'absolute',...css});par.appendChild(s);return s}
function sh(tag,attrs,par){const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);par.appendChild(e);return e}
function bg(t){const f=FX.flip;const q=cx.createLinearGradient(0,0,0,1920);q.addColorStop(0,'#151314');q.addColorStop(.6,'#0E0C0D');q.addColorStop(1,'#050505');cx.fillStyle=q;cx.fillRect(0,0,1080,1920);
  if(f>0){cx.fillStyle=`rgba(60,8,10,${.75*f})`;cx.fillRect(0,0,1080,1920)}
  if(FX.red>0){const r=cx.createRadialGradient(540,700,50,540,700,1000);r.addColorStop(0,`rgba(227,38,46,${.32*FX.red})`);r.addColorStop(1,'rgba(227,38,46,0)');cx.fillStyle=r;cx.fillRect(0,0,1080,1920)}
  const s=30,ox=(t*6)%s,oy=(t*4)%s;for(let y=-s+oy;y<1920+s;y+=s){const a=.15*(1-Math.max(0,(y-1056)/864)*.7);cx.fillStyle=`rgba(255,255,255,${a})`;for(let x=-s+ox;x<1080+s;x+=s){cx.beginPath();cx.arc(x,y,1.6,0,7);cx.fill()}}
  const v=cx.createRadialGradient(540,960,600,540,960,1250);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,.55)');cx.fillStyle=v;cx.fillRect(0,0,1080,1920);
  cx.fillStyle='#C21F28';cx.beginPath();cx.moveTo(460,-4);cx.lineTo(620,-4);cx.lineTo(540,70);cx.closePath();cx.fill()}
function flip(on,at,d=.5){tl.to(FX,{flip:on?1:0,duration:d,ease:'power2.inOut'},at)}
function kick(at,k=1){tl.to(FX,{shake:k,duration:.05},at).to(FX,{shake:0,duration:.4,ease:'power2.out'},at+.05)}
// سطر الكلام: كوفام 96px، سطرين بالكثير، فوق الرسمة فيتعلم over
function cap(par,text,hero,top,opt={}){const bx=el('div','cap',{top:top+'px'},par),s=el('span','txt',{},bx);s.dataset.center='';s.dataset.over='';const heroes=[].concat(hero||[]);
  s.innerHTML=text.split(' ').map(w=>`<span class="w${heroes.includes(w.replace(/[،؟.!:]/g,''))?' '+(opt.cls||'hero'):''}">${w}</span>`).join(' ');s.dataset.text=text;
  let fs=opt.size||96;s.style.fontSize=fs+'px';while(s.offsetHeight>fs*1.3*2.2&&fs>72){fs-=4;s.style.fontSize=fs+'px'}return {box:bx,s,ws:[...s.querySelectorAll('.w')]}}
function capIn(c,at){c.s.style.opacity=0;tl.set(c.s,{opacity:1},at);tl.fromTo(c.ws,{y:46,opacity:0,filter:'blur(10px)'},{y:0,opacity:1,filter:'blur(0px)',duration:.45,ease:'snap',stagger:.08},at)}

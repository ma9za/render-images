const _mc=document.createElement('canvas').getContext('2d');
function inkOff(w){const cs=getComputedStyle(w);_mc.font=`${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;_mc.direction='rtl';_mc.textAlign='left';_mc.textBaseline='alphabetic';
  const m=_mc.measureText(w.textContent);const r=w.getBoundingClientRect();const base=r.top+(r.height-(m.fontBoundingBoxAscent+m.fontBoundingBoxDescent))/2+m.fontBoundingBoxAscent;
  return {l:-m.actualBoundingBoxLeft,r:m.actualBoundingBoxRight-r.width,t:(base-m.actualBoundingBoxAscent)-r.top,b:(base+m.actualBoundingBoxDescent)-r.bottom,w0:r.width}}
function inkOf(w){if(!w._ink)w._ink=inkOff(w);const r=w.getBoundingClientRect(),k=r.width/(w._ink.w0||r.width||1);return {l:r.left+w._ink.l*k,r:r.right+w._ink.r*k,t:r.top+w._ink.t*k,b:r.bottom+w._ink.b*k}}
// القياس وقت البناء: نشيل تحريك الدخول مؤقتاً، وإلا الماركر والإطار يطلعون تحت الكلمة
function flat(ws,fn){const sv=ws.map(w=>[w,w.style.transform,w.style.translate]);ws.forEach(w=>{w.style.transform='none';w.style.translate='none'});const r=fn();sv.forEach(([w,a,b])=>{w.style.transform=a;w.style.translate=b});return r}
function inkUnion(ws){const b=ws.map(inkOf);return {l:Math.min(...b.map(q=>q.l)),r:Math.max(...b.map(q=>q.r)),t:Math.min(...b.map(q=>q.t)),b:Math.max(...b.map(q=>q.b))}}
function local(b,par){const p=par.getBoundingClientRect();return {l:b.l-p.left,r:b.r-p.left,t:b.t-p.top,b:b.b-p.top}}
window.__subj=[];const _marks=[];
// الإطار من حبر الحروف + مسافة
function capFrame(c,at,{px=34,py=18,ws}={}){const b=flat(c.ws,()=>local(inkUnion(ws||c.ws),c.box));const W=b.r-b.l+2*px,H=b.b-b.t+2*py;
  const s=sv(W,H,c.box,{left:(b.l-px)+'px',top:(b.t-py)+'px'});s.classList.add('frm');const r=sh('rect',{x:3.5,y:3.5,width:W-7,height:H-7,rx:24,fill:'none',stroke:RD,'stroke-width':7},s);
  tl.fromTo(r,{drawSVG:'50% 50%'},{drawSVG:'0% 100%',duration:.55,ease:'snap'},at);return r}
// ١ مؤشر الكتابة
function typeOn(c,at,dur){const tot=c.ws.map(w=>w.textContent).join('').length;c.s.style.opacity=0;tl.set(c.s,{opacity:1},at);
  const car=el('div','',{width:'9px',borderRadius:'3px',background:RD,opacity:0},c.box);car.classList.add('caret');
  const P={p:0};const upd=()=>{const W=c.s.offsetWidth,H=c.s.offsetHeight;const p=Math.round(P.p*tot)/tot;c.s.style.clipPath=`inset(-30% 0 -30% ${((1-p)*100).toFixed(2)}%)`;
    car.style.height=(H*.8)+'px';car.style.top=(c.s.offsetTop+H*.1)+'px';car.style.left=(c.s.offsetLeft+(1-p)*W-16)+'px'};
  tl.fromTo(P,{p:0},{p:1,duration:dur,ease:'none',onUpdate:upd,immediateRender:false},at);
  const B={k:0};const T=dur+1.3;tl.fromTo(B,{k:0},{k:1,duration:T,ease:'none',immediateRender:false,onUpdate:()=>{const lt=B.k*T;car.style.opacity=lt>T-.05?0:(lt<dur?1:((lt*2.4)%1<.55?1:0))}},at);
  tl.set(c.s,{clipPath:'none'},at+dur+.01);P.p=0;requestAnimationFrame(upd);return car}
// ٢ ماوس ويب
const ARROW='<svg width="70" height="70" viewBox="0 0 24 24"><path d="M4 2 L4 19 L8.6 14.8 L11.6 21.6 L14.6 20.3 L11.7 13.6 L17.8 13.4 Z" fill="#fff" stroke="#0E0C0D" stroke-width="1.4" stroke-linejoin="round"/></svg>';
function mouseClick(c,wi,at,{from=[980,1780]}={}){const w=c.ws[wi];const sc=c.box.parentElement;const b=flat(c.ws,()=>local(inkOf(w),sc));const cx0=(b.l+b.r)/2,cy0=(b.t+b.b)/2;
  const mk=box('',b.l-14,b.t-6,b.r-b.l+28,b.b-b.t+12,sc,{background:RD,borderRadius:'12px',transformOrigin:'100% 50%',transform:'scaleX(0)'});sc.insertBefore(mk,c.box);_marks.push({el:mk,w,kind:'marker'});att(c,mk);
  const cur=box('cursor',0,0,70,70,sc,{opacity:0,zIndex:5});cur.innerHTML=ARROW;const rip=box('',cx0-60,cy0-60,120,120,sc,{borderRadius:'50%',border:`6px solid ${RD}`,boxSizing:'border-box',opacity:0,zIndex:4});
  tl.set(cur,{opacity:1,left:from[0],top:from[1]},at);tl.to(cur,{left:cx0-6,top:cy0-4,duration:.7,ease:'power3.inOut'},at);
  tl.to(cur,{scale:.82,duration:.08,transformOrigin:'0 0'},at+.72).to(cur,{scale:1,duration:.14},at+.8);
  tl.fromTo(rip,{scale:.2,opacity:1},{scale:1.6,opacity:0,duration:.55,ease:'power2.out',immediateRender:false},at+.74);
  tl.to(mk,{scaleX:1,duration:.32,ease:'power3.out'},at+.76);tl.set(w,{color:'#fff'},at+.82);
  tl.to(cur,{left:'+=140',top:'+=160',opacity:0,duration:.45,ease:'power2.in'},at+1.3);return {cur,mk}}
// ٣ قلم رسم
const PEN='<svg width="64" height="64" viewBox="0 0 24 24"><path d="M3 21 L4.2 15.6 L15.8 4 L20 8.2 L8.4 19.8 Z" fill="#fff" stroke="#0E0C0D" stroke-width="1.2" stroke-linejoin="round"/><path d="M3 21 L4.2 15.6 L8.4 19.8 Z" fill="#E3262E"/></svg>';
function pen(c,at,{kind='under',ws,dur=.7}={}){const sc=c.box.parentElement;const b=flat(c.ws,()=>local(inkUnion(ws||c.ws),sc));const W=b.r-b.l;
  const s=sv(1080,1920,sc,{left:'0px',top:'0px',zIndex:3});let d;
  if(kind==='under'){const y=b.b+16;d=`M${b.r+10} ${y} C${b.r-W*.3} ${y+12} ${b.l+W*.35} ${y-8} ${b.l-12} ${y+6}`}
  else{const cx=(b.l+b.r)/2,cy=(b.t+b.b)/2,rx=W/2+26,ry=(b.b-b.t)/2+26;d=`M${cx+rx*.9} ${cy-ry*.55} C${cx+rx*1.15} ${cy+ry*1.2} ${cx-rx*1.2} ${cy+ry*1.15} ${cx-rx} ${cy} S${cx+rx*.4} ${cy-ry*1.35} ${cx+rx*1.05} ${cy-ry*.2}`}
  const p=sh('path',{d,fill:'none',stroke:RD,'stroke-width':9,'stroke-linecap':'round'},s);const L=p.getTotalLength();_marks.push({el:p,ws:ws||c.ws,kind});att(c,s);
  const pn=box('cursor',0,0,64,64,sc,{opacity:0,zIndex:5});pn.innerHTML=PEN;
  const P={k:0};const upd=()=>{const q=p.getPointAtLength(L*P.k);pn.style.left=(q.x-4)+'px';pn.style.top=(q.y-58)+'px'};
  tl.fromTo(p,{drawSVG:'0%'},{drawSVG:'100%',duration:dur,ease:'power1.inOut'},at);tl.set(pn,{opacity:1},at);
  tl.fromTo(P,{k:0},{k:1,duration:dur,ease:'power1.inOut',onUpdate:upd,immediateRender:false},at);upd();
  tl.to(pn,{opacity:0,y:-30,duration:.3},at+dur+.15);return p}
// ٤ سهم تنقل
function arrowTo(c,wi,at,{side='left'}={}){const sc=c.box.parentElement;const b=flat(c.ws,()=>local(inkOf(c.ws[wi]),sc));const ty=(b.t+b.b)/2;
  const x1=side==='left'?b.l-24:b.r+24,x0=side==='left'?Math.max(40,b.l-230):Math.min(1040,b.r+230),y0=ty-150;
  const s=sv(1080,1920,sc,{left:'0px',top:'0px',zIndex:3});const p=sh('path',{d:`M${x0} ${y0} Q${x0} ${ty} ${x1} ${ty}`,fill:'none',stroke:'#fff','stroke-width':8,'stroke-linecap':'round'},s);
  att(c,s);_marks.push({el:p,ws:[c.ws[wi]],kind:'arrow'});const dir=side==='left'?1:-1;const h=sh('path',{d:`M${x1-22*dir} ${ty-18} L${x1} ${ty} L${x1-22*dir} ${ty+18}`,fill:'none',stroke:'#fff','stroke-width':8,'stroke-linecap':'round','stroke-linejoin':'round',opacity:0},s);
  tl.fromTo(p,{drawSVG:'0%'},{drawSVG:'100%',duration:.45,ease:'power2.in'},at);tl.to(h,{opacity:1,duration:.05},at+.45);
  tl.fromTo(c.ws[wi],{scale:1},{scale:1.12,duration:.18,yoyo:true,repeat:1,immediateRender:false},at+.46);return p}
// ٥ ماركر
function marker(c,wi,at){const w=c.ws[wi];const sc=c.box.parentElement;const b=flat(c.ws,()=>local(inkOf(w),sc));
  const mk=box('',b.l-14,b.t-6,b.r-b.l+28,b.b-b.t+12,sc,{background:RD,borderRadius:'10px',transformOrigin:'100% 50%',transform:'scaleX(0)'});sc.insertBefore(mk,c.box);_marks.push({el:mk,w,kind:'marker'});att(c,mk);
  tl.to(mk,{scaleX:1,duration:.35,ease:'power3.out'},at);tl.set(w,{color:'#fff'},at+.1);return mk}
// كل علامة (ماركر، قلم، سهم، ماوس) تنربط بسطرها وتطلع معه. الماركر والقلم يكونون أخوة للسطر داخل المشهد، فـ capOut القديم كان يخفي الكلام ويخلي الماركر الأحمر لحاله (تركي مسكه). هذا capOut يحل محل اللي بـ lib.js
function att(c,...e){(c._fx=c._fx||[]).push(...e.filter(Boolean))}
function capOut(c,at){tl.to(c.box,{y:-40,opacity:0,duration:.28,ease:'power2.in'},at);if(c._fx&&c._fx.length)tl.to(c._fx,{opacity:0,duration:.22,ease:'power2.in',overwrite:false},at)}
// ═══ فحص الصفحة (المصحح يناديه بكل فريم)
function _op(e){let o=1;for(let x=e;x&&x.nodeType===1;x=x.parentElement){const s=getComputedStyle(x);if(s.display==='none'||s.visibility==='hidden')return 0;o*=parseFloat(s.opacity)}return o}
window.__qa=()=>{const out=[];const caps=[...document.querySelectorAll('#world .cap .txt')].filter(e=>_op(e)>.5);
  const inks=caps.map(c=>{const ws=[...c.querySelectorAll('.w')].filter(w=>w.textContent&&getComputedStyle(w).display!=='none');return ws.length?{t:c.dataset.text,b:inkUnion(ws)}:null}).filter(Boolean);
  const ov=(a,b)=>Math.max(0,Math.min(a.r,b.r)-Math.max(a.l,b.l))*Math.max(0,Math.min(a.b,b.b)-Math.max(a.t,b.t));
  document.querySelectorAll('#world .frm').forEach(f=>{if(_op(f)<.5)return;const R=f.getBoundingClientRect();const inner={l:R.left+12,r:R.right-12,t:R.top+12,b:R.bottom-12};
    for(const I of inks){if(!ov(I.b,R))continue;const inside=I.b.l>=inner.l&&I.b.r<=inner.r&&I.b.t>=inner.t&&I.b.b<=inner.b;if(!inside)out.push(['الإطار يدخل بالحروف أو يلمسها',I.t])}});
  for(const S of window.__subj){const a=(S.x1-S.x0)*(S.y1-S.y0);if(a<=0)continue;const vis=Math.max(0,Math.min(S.x1,1080)-Math.max(S.x0,0))*Math.max(0,Math.min(S.y1,1920)-Math.max(S.y0,0));
    if(!S.cutOK&&vis/a<.92)out.push([`مجسم مقصوص بطرف الشاشة (${Math.round(100-vis/a*100)}% منه برا)`,S.name]);
    const sb={l:S.x0,r:S.x1,t:S.y0,b:S.y1};for(const I of inks){const ia=(I.b.r-I.b.l)*(I.b.b-I.b.t);if(!S.cutOK&&ov(I.b,sb)>.12*ia)out.push(['الكلام فوق المجسم',I.t+' ⟂ '+S.name])}}
  const _drawn=e=>{if(e.tagName!=='path')return true;const d=getComputedStyle(e).strokeDasharray;if(!d||d==='none')return true;return parseFloat(d)>2};
  for(const M of _marks){if(_op(M.el)<.5||!_drawn(M.el))continue;const R=M.el.getBoundingClientRect();if(R.width<4)continue;
    const ws=(M.ws||[M.w]).filter(w=>_op(w)>.5);if(!ws.length){out.push(['علامة باقية بعد ما راح كلامها ('+M.kind+')',(M.ws||[M.w]).map(w=>w.textContent).join(' ')]);continue}const I=inkUnion(ws);const ia=(I.r-I.l)*(I.b-I.t);const nm=ws.map(w=>w.textContent).join(' ');
    if(M.kind==='marker'){const tr=getComputedStyle(M.el).transform;const full=!tr||tr==='none'||/matrix\(1,/.test(tr);if(full&&ov(I,{l:R.left,r:R.right,t:R.top,b:R.bottom})<.8*ia)out.push(['الماركر منزاح عن كلمته',nm])}
    else if(M.kind==='under'){if(R.top<I.b-14||R.top>I.b+40||Math.min(R.right,I.r)-Math.max(R.left,I.l)<.6*(I.r-I.l))out.push(['خط القلم مو تحت كلمته',nm])}
    else if(M.kind==='circle'){if(!(R.left<=I.l+6&&R.right>=I.r-6&&R.top<=I.t+10&&R.bottom>=I.b-10))out.push(['دائرة القلم ما تحيط بكلمتها',nm])}}
  return out};
